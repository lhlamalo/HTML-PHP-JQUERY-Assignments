<?php
 include_once('connect.php');
 $query_string='
  CREATE TABLE register (
    username varchar(20),
     password varchar(40) PRIMARY KEY,
	 email varchar(60),
	 phone int(10)
	 
  )
   ';

   if($help_conn->query($query_string)){
	   
	   echo "Table successfully created";
   }
?>

<!doctype html>
<html>
<body>
</body>
</html>