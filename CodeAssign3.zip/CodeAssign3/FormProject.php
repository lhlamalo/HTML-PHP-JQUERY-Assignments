<!Doctype html>

<html>
<head>

<link rel="stylesheet" href="formCss.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.css">
<script src="jquery-2.2.0.js"></script>
<script src="jquery.js"></script>


</head>

<body style="background-color:blue">
<header>
<div id=title>
<h1>
HELPDESK ENGINE
</h1>
</div>
<div>
<h2>
Create New User
</h2>
</div>
</header>
<section>
<div>
<form action="InfoDisplay.php" method = "post"  id="">
<label>
      First Name
</label>
<input type="text" id="fname" name="fname" class="fname" required><span id="err_fname"></span><br><br>
<label>
      Last Name
</label>
<input type="text" id="lname" name="lname" class="lname" required><span id="err_lname"></span><br><br>
<label>
      Other Names
</label>
<input type="text" id="oname" name="oname" class="oname"><br><br>
<label>
      UserName
</label>
<input type="text" id="username" name="username" class="username" required><span id="err_uname"></span><br><br>
<label>
      Gender
</label>
Male <input type="radio" value="Male" name="gender" id="sex" class="sex" >
Female <input type="radio" value="Female" name="gender" id="sex" class="sex"><br><br>

<label>
      Password
</label>
<input type="password" id="password" name="password" class="password" required ><span id="err_pass"></span><br><br>
<label>
     Contact Number
</label>
<input type="number" id="pnumber" name="pnumber" class="pnumber" required ><br><br>
<label>
      Retype Password
</label>
<input type="password" id="password2" name="password2"class="password2" required ><span id="retype_err_pass"></span><br><br>
<label>
      Email
</label>
<input type="email" id="email" name="email" class="email" required><span id="err_email"></span><br><br>
<label>
      Retype Email
</label>
<input type="email" id="email2" name="email2" class="email2" required><span id="err_email_retype"></span><br><br>
<label> 
User Role
</label>
<select name="userrole" >
<option value=""> </option>
<option value="Requestor"  required>Requestor </option>
<option value="Technician"  required>Technician </option>
<option value="Engineer" required>Engineer</option><br><br>
</select><br><br>
<input type="submit" name="submit" id="submit" value= "SAVE">
<input type="reset" name="reset" id="reset" value= "CLEAR">

</form>
</div>
</section>
<footer>
Logged in as Administrator <br>
<small> Copyright Lovemore 2016</small>
<footer>
</body>


</html> 