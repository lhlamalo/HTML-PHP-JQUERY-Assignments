<?php
include_once('connect.php');
if(isset($_POST['username'])&&isset($_POST['password'])){
	
$username= $_POST['username'];
$password = $_POST['password'];

  if(!empty($username)&&!empty($password)){
	$query_string="SELECT * FROM users where username ='$username' and password ='$password' ";
 $resultSet=$help_conn->query($query_string);
 $numberOfRows=$resultSet->num_rows;
 for($count=0;$count<$numberOfRows;$count++){
	 $userObject=$resultSet->fetch_object();
	 echo $userObject->username.", ".$userObject->password."<br>";
	 $_SESSION['welcome'] = $index;
 header("Location:HomeMenu/index.php"); // Redirect user to index.php
 
	}

  }else{
	  echo'please fill in the fields'.'<br>';
  } 
}

?>
<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               


<form action="UserLogin.php" method="POST">
<label>username  :</label>  <input type="text" name="username" class="box"><br><br>
<label>password  :</label>  <input type="password" name="password" class="box"><br><br>
<input type="submit" value="login"><br>
				</form>
			</div>
		</div>
	</div>
</body>
</html>