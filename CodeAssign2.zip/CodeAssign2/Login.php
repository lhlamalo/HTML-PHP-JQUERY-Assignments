<!Doctype html>

<html>
<head>

<link rel="stylesheet" href="formCss.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.css">
<script src="jquery-2.2.0.js"></script>
<script src="jquery.js"></script>


</head>

<body style="background-color:blue">
<header>
<div id=title>
<h1>
HELPDESK ENGINE
</h1>
</div>
<div>
<h2>
Admin Login
</h2>
</div>
</header>
<section>
<div>
<form action="LoginValidation.php" method = "post"  id="">

<label>
      UserName
</label>
<input type="text" id="username" name="username" class="username" required><span id="err_uname"></span><br><br>

<label>
      Password
</label>
<input type="password" id="password" name="password" class="password" required ><span id="err_pass"></span><br><br>
<input type="submit" name="submit" id="submit" value= "SAVE">
<input type="reset" name="reset" id="reset" value= "CLEAR">


</body>


</html> 