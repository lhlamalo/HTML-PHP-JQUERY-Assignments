<?php
$fname =$_POST["fname"];
$lname =$_POST["lname"];
$gender =$_POST["gender"];
$username =$_POST["username"];
$password =$_POST["password"];
$password2 =$_POST["password2"];
$email =$_POST["email"];
$pnumber =$_POST["pnumber"];
$usertype =$_POST["userrole"];


 
 
 
 if(!empty ($fname && $lname && $gender && $username && $password && $email && $password2 && $pnumber && $usertype )){
	?> 
<html>
<head>

<link rel="stylesheet" href="formCss.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.css">
</head>
<body bgcolor="red">
<h1>User Information</h1>

<?php
echo"First Name: $fname<br>";
	echo"Last Name: $lname <br> ";
	echo"Gender: $gender <br> ";
	echo"Username: $username <br> ";
	echo"Password: $password <br> ";
	echo"Email: $email <br>";
	echo"Phone: $pnumber <br>";
	echo"User role: $usertype<br>";
	?>
</body>
</html>
<?php
}else{
		echo" Please fill in all the values";
	}
?>